#max_row=int(input("Enter a number?"))
#max_col=int(input("Enter a number?"))

#for x in range(1,(max_row+1)):
 #   for y in range(1,(max_col+1)):
  #      print(x*y, end=" ")
   # print()
   
dir()