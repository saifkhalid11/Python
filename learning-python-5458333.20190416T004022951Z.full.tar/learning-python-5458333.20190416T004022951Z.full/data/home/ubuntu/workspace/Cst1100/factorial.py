def factorial(N=0):
    if N==0:
        return 1
    else:
        return N*factorial(N-1)

print (factorial(3))

#recursive something calls itself