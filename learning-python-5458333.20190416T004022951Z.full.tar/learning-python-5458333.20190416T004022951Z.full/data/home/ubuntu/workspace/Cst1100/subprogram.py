def mySubprogram(i=9):
    z="hey how are you?"
    print("Sub program has just been called",str(i))
    brooklyn(z)

def brooklyn(iphone=" i am not feeling good"):
    print("Daylight savings time has ended", iphone)
    return"iphone is dying", iphone


z=123
mySubprogram(z)
android="let's go fishing"
print(brooklyn(android))