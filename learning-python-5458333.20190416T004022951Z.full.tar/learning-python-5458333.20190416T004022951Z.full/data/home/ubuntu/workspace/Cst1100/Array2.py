def binary_search():
    item_list=['ant','cat','chicken','cow','deer','dog','fish','goat','horse','rat','snake']
    item='dog'
    first=0
    last=len(item_list)-1
    found=False
    while(first<=last and not found):
        mid=(first+last)//2
        print(" First="+item_list[first]+" Last="+item_list[last]+" Mid="+item_list[mid])
        if(item_list[mid]==item):
            found=True
        else:
            if(item<item_list[mid]):
                last=mid-1
            else:
                first=mid+1
        return found            
    
print(binary_search())