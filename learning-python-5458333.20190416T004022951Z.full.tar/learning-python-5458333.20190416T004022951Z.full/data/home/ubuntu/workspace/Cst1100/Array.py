imit=input("How many values?")
data=[2,3,54,6]
index = 0
while (index<len(data)):
    data[index]=input("Enter a number")
    index = index+1

print(data[4])