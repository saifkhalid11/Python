#def get_user_name():
#    name= input("Please enter your name:")
#    print (name)
#    return name
#name=get_user_name()

#def get_total(numbers):
#    total=0
#    for i in numbers:
#        total=total+i
#        
#    return total
#print("Hello",name,", The game has started")

#nums=[12,4,5,6,6,7,8,9]

#total=get_total(nums)

#print("The total is : ",total )


def create_vip_list():
    killcode=":quit"
    name=""
    guest_list=[]
    while name != killcode:
        name = input("Please enter a name :")
        if name != killcode:
            guest_list.append(name)
            print ("You have added {0} to the guest list".format(name))
    return guest_list
    
def print_list(guests):
    for i in guests:
        print(i)

names=create_vip_list()
print_list(names)