is_train_running=True
is_bus_running=False
is_uber_available=True
print("AND results")
if is_train_running and is_bus_running and is_uber_available:
    print("I can go to school")
else:
    print("I stay home")
print("OR results")


if is_train_running or is_bus_running or is_uber_available:
    print("I can go to school")
else:
    ("I stay home")
