users=["sara","johnny","Susan","mary"]
print(users)


name=input("Please enter your name.")

#adds object to the end of the list
#users.append(name)


#inserts name at the specified index
#users.insert(1, name)


#for n in users:
 #   if(n.lower().startswith('s')):
  #      print(n.lower())

killcode=":quit"
name=""
while name!=killcode:
    name=input("Please enter a name :")
    if name!= killcode:
        user.append(name)
        print("You've added {0} to the guest list".format(name))
        
for n in users:
    print (n)


print(users)