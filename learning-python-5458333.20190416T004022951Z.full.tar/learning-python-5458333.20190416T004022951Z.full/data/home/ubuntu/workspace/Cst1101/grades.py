grade1=float(input("what did you get in English:"))
grade2=float(input("what did you get in Science:"))
grade3=float(input("what did you get in Math:"))

Avg=(grade1+grade2+grade3)/3
print("Your average is", Avg)

if Avg>=90:
    print("Awesome average")
elif Avg>=80:
    print("Great average")
else:
    print("need improvement")

