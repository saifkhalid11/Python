for i in range(0,101):
    
    if i % 3==0 and i % 5==0:
        print (i,"Shark Attack")    
    elif i % 3==0:
        print (i,"Shark")
    elif i % 5==0:
        print (i,"Attack")
    else:
        print(i)