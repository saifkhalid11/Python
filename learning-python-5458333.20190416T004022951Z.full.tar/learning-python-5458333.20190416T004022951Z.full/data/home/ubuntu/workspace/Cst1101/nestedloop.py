max_row =13
max_col=13


#for row in range(0,max_row):
#    print("*")
#    for col in range(0,max_col):
#        print("*", end=" ")
#    print("")
    
    
#for row in range(1,max_row):
    #print("*")
#    for col in range(1,max_col):
#        print(row*col, end=" ")
#    print("")


#for rack in range(1,max_row):
 #   print("Runs to Rack:",rack)
  #  for ball in range(1,max_col):
   #     print("Shoot Ball: ", ball, end=" ")
    #    for time in range(1,3):
     #       print()
      #      print(time,"seconds")
       #     counter=0
        #    while counter<=9:
         #       print (counter,"",end="")
          #      counter+=1
           # print()
            #
#    print("")





#for row in range(0,max_row):
    
#    for col in range(0,max_col):
#        print("*",end="")
#        
#    print()
    
    
#for x in range(1,max_row):
#    for y in range(1,max_col):
#        print(x*y,end="")
#    print()
        