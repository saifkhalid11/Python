letters=["a","b","c"]
for i in letters:
    print(i)