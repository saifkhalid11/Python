#student=[
#    ["Johnny",77,78]
#    ,["Susan",99,98]
#    ,["Mary" ,100,100]
#]

#for stdnt in student:
#    average=(stdnt[1]+stdnt[2])/2
#    print(stdnt[0],average)
#
#print(student)


#+ "\t"

grocery_list=[
    ["Milk",1,3.99]
    ,["Bread",2,2.99]
    ,["Eggs",2,2.79]
]
subtotal=0
for item in grocery_list:
    #print(item)
    quantity = item[1]
    price=item[2]
    total=quantity*price
    subtotal += total
    #subtotal=subtotal+total
    for info in item:
        print(info,end="\t")
    print(total)
print("-"*30)
print("Sub Total :",subtotal )
print("Total :", subtotal*1.08875)