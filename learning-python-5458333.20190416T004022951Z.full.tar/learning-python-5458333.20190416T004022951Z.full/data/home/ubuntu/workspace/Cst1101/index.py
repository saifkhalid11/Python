import mylib as l
 
numbers = [ 9,8,7,6,5,4,3]
 
total = l.get_total(numbers)
print("The total is", total)
#name = l.get_user_name()
 
names=l.create_vip_list()
#l.print_list(names)

for idx, n in enumerate(names):
    print("position: ", idx,"value: ",n)