#def function name():
#   code here
#   more code


def sayHello(name):
    print("Hello", name)
    
sayHello("me")

def add(x,y):
    print(x+y)

add(5,9)

def get_sales_tax(state):
    if state=="ny":
        return 1.08875
    elif state=="fl":
        return 1.06
    else:
        return 1
tax=get_sales_tax("ny")
Game_price=59.99
Total=Game_price*tax
print(Total)
#print(get_sales_tax())