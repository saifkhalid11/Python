#while boolean_expression:
    #code here
    #!= means not equal
#    
#counter=0
#while counter<10:
    
    #counter=counter+1
#    print("The counter is",counter)
#    counter=counter+1

killcode=":quit"
name=""
while name!=killcode:
    name=input("Please enter a name :")
    if name!= killcode:
        print("You've added {0} to the guest list".format(name))
    
print("Program Completed")