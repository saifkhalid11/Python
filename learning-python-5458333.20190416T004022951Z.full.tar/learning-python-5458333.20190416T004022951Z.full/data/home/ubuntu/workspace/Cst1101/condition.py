#total=100
#boolean expression ecvaluate to true or false
#
#< less than
#> greater than
#>= greater than or equal to
#<= less than or equal to
#== equal to

#if total>50:
#    print("Success")

game_count=int(input ("How many games would you like to purchase?"))
game_price=60
sub_total= game_count*game_price
if sub_total>= 120:
    print("You got 10% discount :)")
    sub_total= sub_total-(sub_total*.10)
    
print("your subtotal is ", sub_total)
tax=1.08875
total=sub_total*tax
print("your total is ", total)
#tax=float(input ("What is the sales tax?"))
#if tax >=1:
#    print("put tax in decimal")
#    tax=float(input ("What is the sales tax?"))
#else:
#    total=(total *tax)+total
#print("your total is ", total)