#for loop
for index in range(110,0,-1):
    print(index)