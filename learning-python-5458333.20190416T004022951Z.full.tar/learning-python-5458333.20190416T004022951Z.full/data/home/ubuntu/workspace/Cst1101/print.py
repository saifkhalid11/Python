price=59.99
quantity=2
sales_tax=1.0875

total=price*quantity*sales_tax
print (total)
#print it nicer
print("Your total is $"+str(total))
print("Your total is $",total,"Thanks For Shopping with us")
print("Your total is $",total,"Thanks For Shopping with us",sep='$$$')
#end
help(print)
