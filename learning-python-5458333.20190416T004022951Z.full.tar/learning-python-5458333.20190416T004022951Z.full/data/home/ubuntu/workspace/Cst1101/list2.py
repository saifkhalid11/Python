#ways to create empty list
#names=[]
#names=list()

#init  a list with values
#groceries=["milk","eggs","Cheese","Bread"]
#groceries.append("Doritos")
#groceries.insert(0,"butter")

#for item in groceries:
 #   print (item)
    

students=[]
killcode=":quit"
name=""

while name!=killcode:
    studentInfo=[]
    name=input("please enter a name: ")
    if name != killcode:
        studentInfo.append(name)
        score=float(input("Please enter a test score: "))
        studentInfo.append(score)
        #added student info to the student list
        students.append(studentInfo)
        
        major=input("Please enter the major:")
        studentInfo.append(major)
        #adds student info to the stuent lis
        students.append(studentInfo)
        
#for student in students:
#    for info in students:
#        print(info, end=' ')
#    
#    print()

total_grade=0

for student in students:
    print(student[0]+" "+student[2])
    total_grade = total_grade+student[1]

average=total_grade/len(students)

for student in students:
    for info in student:
        print(info, end=' ')
    
    print()


print(total_grade)            
print(students)
print(average)