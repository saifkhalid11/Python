groups=[1,2,3]

team1=["Anthony","Joel","Kai"]
team2=["Susan","Mary","Johnny"]

print(groups)

groups.append(team1)
print(groups)

groups.extend(team2)

print(groups)