def get_user_name( ):
    name = input("Please enter your name: ")   
    return name
 
def get_total(numbers):
    total = 0
    for i in numbers:
       total = total + i
 
    return total
 
def create_vip_list():
    killcode = ":quit"
    name = ""
    guest_list = []
    while name != killcode:
        
        name = input("Please enter a name ")
        if name != killcode:
            guest_list.append(name)
            print("    You've added {0} to the guest list".format(name))
    return guest_list
 
def print_list(guests):
    for n in guests:
        print(n)
     
    print("All names printed")
 
print("inside mylib file",__name__)
if __name__ == "__main__":
    names = ["Jake","Tammy","Sammy","Kenny"]
    print_list(names)