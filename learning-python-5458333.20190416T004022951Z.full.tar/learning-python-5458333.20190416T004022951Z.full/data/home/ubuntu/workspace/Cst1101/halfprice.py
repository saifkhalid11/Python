print("Welcome to professor best BestMart Video Game Sale")

game_count=int(input ("How many games would you like to purchase?"))

video_game=59.99
total=(game_count*video_game)
#if game_count>=2:
 #   print("You get the second game half price")
  #  total=(total)-(video_game/2)
   # print("your total is ",total)

 
#else:
#    print("your total is ",total)

if game_count==2:
    print("you got second game half price")
    total=total-(video_game/2)
    print("your total is ", total)
elif game_count==3:
    print("you got second and third game half price")
    total=total-video_game
    print("your total is ", total)
elif game_count>=4:
    print("you got second and third game half price and fourth game free")
    total=total-(video_game*2)
    print("your total is ",total)
else:
    print("your total is ",total)