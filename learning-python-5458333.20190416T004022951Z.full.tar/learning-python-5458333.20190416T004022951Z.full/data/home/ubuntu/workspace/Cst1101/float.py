name=input("Please enter your name: ")
email=input("Please enter your email: ")
print("Hello",name.upper(),"Your email is",email.upper() )
game_count=int(input ("How many games would you like to purchase?"))
game_price=60
total= game_count*game_price
print("Your total is", total)
sales_tax=float(input ("What is the sales tax?"))
sales_tax_total=total*sales_tax
print("Your total is", sales_tax_total)