choose=input("Choose rock or paper or scissor")
rock=true
if choose==rock:
    print("scissor")OR("paper")