#for i in range(0,11):
#    if i ==5:
#        continue
#    print(i,end=" ")

#for i in range(0,11):
#    if i ==5:
 #       break
 #   print(i,end=" ")


name=["Johnny","susan","Mary", "Tony"]

for idx,n in enumerate(name):
    print(idx,n)